// Shared UI primitives for Maxim Fit
const { useState, useEffect, useRef, useMemo, Fragment } = React;

// ─────────── Icons (line, 1.5px stroke) ───────────
const Icon = {
  protocols: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><rect x="4" y="4" width="16" height="16"/><path d="M4 9h16M9 4v16"/></svg>,
  chat: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><path d="M4 5h16v11H9l-5 4V5z"/></svg>,
  progress: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><path d="M4 20V4M4 20h16M8 16V10M12 16V6M16 16v-4M20 16v-8"/></svg>,
  settings: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></svg>,
  plus: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="square"><path d="M12 5v14M5 12h14"/></svg>,
  chevDown: (s=12) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="square"><path d="M6 9l6 6 6-6"/></svg>,
  chevRight: (s=12) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="square"><path d="M9 6l6 6-6 6"/></svg>,
  chevLeft: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="square"><path d="M15 6l-6 6 6 6"/></svg>,
  check: (s=12) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="square"><path d="M4 12l5 5L20 6"/></svg>,
  edit: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><path d="M4 20h4l10-10-4-4L4 16v4z"/></svg>,
  close: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="square"><path d="M5 5l14 14M19 5L5 19"/></svg>,
  dot: (s=6) => <svg width={s} height={s} viewBox="0 0 6 6"><circle cx="3" cy="3" r="3" fill="currentColor"/></svg>,
  history: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l3 2"/></svg>,
  search: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/></svg>,
  flame: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><path d="M12 3c3 4 5 6 5 10a5 5 0 01-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-5 1-9z"/></svg>,
  send: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><path d="M4 12l16-8-6 16-3-7-7-1z"/></svg>,
  spark: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square"><path d="M12 3v6M12 15v6M3 12h6M15 12h6M6 6l4 4M14 14l4 4M6 18l4-4M14 10l4-4"/></svg>,
};

// ─────────── Score tile ───────────
function ScoreTile({ value, label, tone='default', suffix='', size='md' }) {
  const color = tone==='good' ? 'var(--verified)' : tone==='warn' ? 'var(--warn)' : 'var(--fg)';
  const numSize = size==='lg' ? 36 : size==='sm' ? 20 : 28;
  return (
    <div className="tile" style={{ minWidth: 72 }}>
      <div className="mono" style={{ fontSize: numSize, fontWeight: 500, color, lineHeight: 1, letterSpacing: '-0.02em' }}>
        {value}{suffix && <span style={{ fontSize: numSize*0.45, color: 'var(--fg-3)', marginLeft: 2 }}>{suffix}</span>}
      </div>
      <div className="score-label">{label}</div>
    </div>
  );
}

// ─────────── Verified chip ───────────
function VerifiedChip({ verified, sources, onClick }) {
  if (verified) return (
    <button onClick={onClick} className="chip chip-verified" style={{ background: 'transparent', cursor: 'pointer' }}>
      {Icon.check(10)} VERIFIED · {sources} SRC
    </button>
  );
  return (
    <button onClick={onClick} className="chip chip-unverified" style={{ background: 'transparent', cursor: 'pointer' }}>
      <span style={{ width: 6, height: 6, background: 'var(--warn)', borderRadius: 999 }} /> UNVERIFIED
    </button>
  );
}

// ─────────── Sparkline ───────────
function Sparkline({ data, w=120, h=28, showDot=true, color='var(--accent)' }) {
  if (!data?.length) return null;
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const stepX = w / (data.length - 1);
  const pts = data.map((v, i) => [i*stepX, h - ((v-min)/range)*(h-4) - 2]);
  const d = pts.map((p,i) => (i===0?'M':'L') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
  const area = d + ` L ${w} ${h} L 0 ${h} Z`;
  const last = pts[pts.length-1];
  return (
    <svg width={w} height={h} style={{ display: 'block' }}>
      <path d={area} fill={color} opacity="0.1" />
      <path d={d} stroke={color} strokeWidth="1.5" fill="none" />
      {showDot && <circle cx={last[0]} cy={last[1]} r="2" fill={color} />}
    </svg>
  );
}

// ─────────── Bars mini ───────────
function MiniBars({ data, w=120, h=28, color='var(--accent)' }) {
  const max = Math.max(...data);
  const bw = w / data.length - 1;
  return (
    <svg width={w} height={h} style={{ display: 'block' }}>
      {data.map((v, i) => {
        const bh = (v/max)*(h-2);
        return <rect key={i} x={i*(bw+1)} y={h-bh} width={bw} height={bh} fill={color} opacity={i===data.length-1?1:0.4} />;
      })}
    </svg>
  );
}

// ─────────── Heatmap (adherence calendar) ───────────
function Heatmap({ weeks=12, seed=1 }) {
  const cells = [];
  let s = seed;
  for (let i = 0; i < weeks*7; i++) {
    s = (s*9301 + 49297) % 233280;
    const v = s / 233280;
    const level = v < 0.08 ? 0 : v < 0.25 ? 1 : v < 0.55 ? 2 : v < 0.85 ? 3 : 4;
    cells.push(level);
  }
  const colors = ['#13271C', '#1F3D2B', '#2A5A3E', '#3D7F56', '#4AA373'];
  return (
    <div style={{ display: 'flex', gap: 2 }}>
      {Array.from({length: weeks}).map((_, wi) => (
        <div key={wi} style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {Array.from({length: 7}).map((_, di) => (
            <div key={di} style={{ width: 10, height: 10, background: colors[cells[wi*7+di]] }} />
          ))}
        </div>
      ))}
    </div>
  );
}

// ─────────── Staged streaming bar ───────────
function StreamingStages({ stages, active, done }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {stages.map((s, i) => {
        const isDone = done.includes(i);
        const isActive = i === active;
        return (
          <div key={i} className="lb" style={{ borderLeftColor: isDone ? 'var(--accent)' : isActive ? 'var(--accent)' : 'var(--line)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div className="mono tracked-sm" style={{ color: isActive || isDone ? 'var(--fg)' : 'var(--fg-3)' }}>
                {String(i+1).padStart(2,'0')} · {s.label}
              </div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)' }}>
                {isDone ? 'DONE' : isActive ? <span className="pulse">RUNNING</span> : 'WAIT'}
              </div>
            </div>
            <div className="bar" style={{ marginTop: 6 }}>
              <span style={{ width: isDone ? '100%' : isActive ? '62%' : '0%' }} />
            </div>
            {(isActive || isDone) && <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 4 }}>{s.sub}</div>}
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, { Icon, ScoreTile, VerifiedChip, Sparkline, MiniBars, Heatmap, StreamingStages });
