// Maxim Fit — Tab screens (Protocols, Chat, Progress, Settings)
const { useState: useStateT, useEffect: useEffectT, useRef: useRefT } = React;

// ─────────── Header (app-level) ───────────
function MFHeader({ title, right, sub }) {
  return (
    <div style={{ padding: '14px 20px 10px', borderBottom: '1px solid var(--line)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>MAXIM · FIT</div>
          <div style={{ fontSize: 22, fontWeight: 500, marginTop: 2, letterSpacing: '-0.02em' }}>{title}</div>
        </div>
        {right}
      </div>
      {sub && <div className="mono" style={{ fontSize: 11, color: 'var(--fg-3)', marginTop: 6 }}>{sub}</div>}
    </div>
  );
}

// ─────────── Protocols list ───────────
function ProtocolsTab({ onOpen }) {
  const [menu, setMenu] = useStateT(false);
  const today = new Date(2026, 3, 19);
  const dateStr = today.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }).toUpperCase();

  return (
    <div className="mf-scroll" style={{ height: '100%', overflowY: 'auto', paddingBottom: 100 }}>
      <MFHeader
        title="Protocols"
        sub={`${dateStr} · ${PROTOCOLS.length} ACTIVE · V0.4.2`}
        right={
          <div style={{ position: 'relative' }}>
            <button className="btn btn-primary" onClick={() => setMenu(v => !v)} style={{ padding: '8px 12px', display: 'flex', gap: 6, alignItems: 'center' }}>
              NEW {Icon.chevDown(10)}
            </button>
            {menu && (
              <div style={{ position: 'absolute', top: 38, right: 0, background: 'var(--surface)', border: '1px solid var(--line-2)', minWidth: 160, zIndex: 10 }} className="fade-in">
                <div className="mono" style={{ fontSize: 12, padding: '10px 12px', borderBottom: '1px solid var(--line)', cursor: 'pointer' }} onClick={() => { setMenu(false); onOpen('generating'); }}>↑ GENERATE</div>
                <div className="mono" style={{ fontSize: 12, padding: '10px 12px', cursor: 'pointer', color: 'var(--fg-2)' }} onClick={() => setMenu(false)}>↓ IMPORT</div>
              </div>
            )}
          </div>
        }
      />

      {/* Active protocol card */}
      <div style={{ padding: '16px 20px 8px' }}>
        <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>ACTIVE TODAY</div>
        <div onClick={() => onOpen('detail', PROTOCOLS[0].id)} style={{ background: 'var(--surface)', border: '1px solid var(--line-2)', borderLeft: '2px solid var(--accent)', padding: 14, cursor: 'pointer' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 16, fontWeight: 500, letterSpacing: '-0.01em' }}>{PROTOCOLS[0].name}</div>
              <div className="mono" style={{ fontSize: 11, color: 'var(--fg-3)', marginTop: 4 }}>V{PROTOCOLS[0].version} · {PROTOCOLS[0].createdAt}</div>
            </div>
            <VerifiedChip verified={PROTOCOLS[0].verified} sources={PROTOCOLS[0].sources} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginTop: 14 }}>
            <ScoreTile value={PROTOCOLS[0].goalScore} label="GOAL" tone="good" />
            <ScoreTile value={PROTOCOLS[0].viabilityScore} label="VIABILITY" tone="good" />
            <div className="tile">
              <div className="mono" style={{ fontSize: 12, color: 'var(--fg-2)' }}>
                <Sparkline data={PROGRESS_METRICS.hrv} w={72} h={20} />
              </div>
              <div className="score-label">HRV · 14D</div>
            </div>
          </div>
          <div className="mono" style={{ fontSize: 11, color: 'var(--fg-2)', marginTop: 12, lineHeight: 1.5 }}>
            {PROTOCOLS[0].summary}
          </div>
        </div>
      </div>

      {/* Other protocols */}
      <div style={{ padding: '16px 20px 0' }}>
        <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>ALL · {PROTOCOLS.length}</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--line)' }}>
          {PROTOCOLS.slice(1).map(p => (
            <div key={p.id} onClick={() => onOpen('detail', p.id)} style={{ background: 'var(--bg)', padding: 12, cursor: 'pointer', borderLeft: `2px solid ${p.verified ? 'var(--accent)' : 'var(--warn)'}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, fontWeight: 500 }}>{p.name}</div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 3 }}>V{p.version} · {p.createdAt} · {p.sources} SRC</div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <div className="mono" style={{ fontSize: 13, color: 'var(--fg)' }}>{p.goalScore}<span style={{ color: 'var(--fg-3)', fontSize: 9 }}>/G</span></div>
                  <div className="mono" style={{ fontSize: 13, color: 'var(--fg)' }}>{p.viabilityScore}<span style={{ color: 'var(--fg-3)', fontSize: 9 }}>/V</span></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────── Chat tab ───────────
function ChatTab() {
  const [messages, setMessages] = useStateT(CHAT_HISTORY);
  const [input, setInput] = useStateT('');
  const [streaming, setStreaming] = useStateT(null);
  const endRef = useRefT(null);

  useEffectT(() => { endRef.current?.scrollTo({ top: 9999 }); }, [messages, streaming]);

  const suggested = ['Is creatine safe long-term?', 'How much protein per meal?', 'Best time for cardio?'];

  function send(text) {
    if (!text.trim()) return;
    setMessages(m => [...m, { id: Date.now(), role: 'user', text }]);
    setInput('');
    const reply = "Based on 2024 meta-analyses, consensus points toward distributing 0.4–0.5g protein/kg per meal across 4–5 feedings. Maximal MPS requires ~3g leucine per bolus, typically hit with 30–40g of high-quality protein. Timing matters less than total daily intake, but even spacing outperforms skewed distribution for net anabolism.";
    let i = 0;
    setStreaming({ text: '', sources: [1, 2, 3] });
    const iv = setInterval(() => {
      i += 4;
      if (i >= reply.length) {
        clearInterval(iv);
        setMessages(m => [...m, { id: Date.now()+1, role: 'ai', text: reply, sources: [1, 2, 3] }]);
        setStreaming(null);
      } else {
        setStreaming({ text: reply.slice(0, i), sources: [1, 2, 3] });
      }
    }, 22);
  }

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <MFHeader title="Chat" sub="CLINICAL ASSISTANT · GPT-5.2 · RAG" />
      <div ref={endRef} className="mf-scroll" style={{ flex: 1, overflowY: 'auto', padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {messages.map(m => <ChatMessage key={m.id} msg={m} />)}
        {streaming && <ChatMessage msg={{ role: 'ai', text: streaming.text, sources: streaming.sources, streaming: true }} />}
        {!streaming && (
          <div style={{ marginTop: 8 }}>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 6 }}>SUGGESTED</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {suggested.map(q => (
                <div key={q} onClick={() => send(q)} className="mono" style={{ fontSize: 12, padding: 10, border: '1px solid var(--line)', color: 'var(--fg-2)', cursor: 'pointer' }}>→ {q}</div>
              ))}
            </div>
          </div>
        )}
      </div>
      <div style={{ padding: '10px 16px 12px', borderTop: '1px solid var(--line)', background: 'var(--bg-2)' }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key==='Enter' && send(input)} placeholder="Ask about your protocol…" style={{ flex: 1 }} />
          <button className="btn btn-primary" onClick={() => send(input)} style={{ padding: '10px 12px' }}>{Icon.send(14)}</button>
        </div>
      </div>
    </div>
  );
}

function ChatMessage({ msg }) {
  const isUser = msg.role === 'user';
  return (
    <div style={{ display: 'flex', justifyContent: isUser ? 'flex-end' : 'flex-start' }}>
      <div style={{ maxWidth: '86%' }}>
        <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 4, textAlign: isUser ? 'right' : 'left' }}>
          {isUser ? 'YOU' : 'ASSISTANT'}
        </div>
        <div style={{
          background: isUser ? 'var(--surface-2)' : 'transparent',
          border: isUser ? '1px solid var(--line-2)' : 'none',
          borderLeft: isUser ? '1px solid var(--line-2)' : '2px solid var(--accent)',
          padding: isUser ? '10px 12px' : '2px 0 2px 12px',
          fontSize: 14, lineHeight: 1.55, color: 'var(--fg)',
        }}>
          {msg.text}{msg.streaming && <span className="caret" style={{ marginLeft: 2, background: 'var(--accent)', width: 7, height: 14, display: 'inline-block', verticalAlign: 'middle' }} />}
        </div>
        {msg.sources && !msg.streaming && (
          <div style={{ display: 'flex', gap: 4, marginTop: 6, flexWrap: 'wrap' }}>
            {msg.sources.map(s => (
              <span key={s} className="mono" style={{ fontSize: 9, color: 'var(--fg-3)', border: '1px solid var(--line)', padding: '2px 5px' }}>[{s}] {SOURCES[s-1]?.author.split(' ')[0]}·{SOURCES[s-1]?.year}</span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────── Progress tab ───────────
function ProgressTab() {
  const metrics = [
    { label: 'WEIGHT', unit: 'KG', data: PROGRESS_METRICS.weight, current: 80.7, delta: -1.4, good: true },
    { label: 'SLEEP', unit: 'H/NIGHT', data: PROGRESS_METRICS.sleep, current: 8.3, delta: +1.1, good: true },
    { label: 'BENCH 1RM', unit: 'KG', data: PROGRESS_METRICS.bench, current: 105, delta: +15, good: true },
    { label: 'HRV', unit: 'MS', data: PROGRESS_METRICS.hrv, current: 66, delta: +14, good: true },
  ];
  return (
    <div className="mf-scroll" style={{ height: '100%', overflowY: 'auto', paddingBottom: 100 }}>
      <MFHeader title="Progress" sub="LAST 14D · COMPILED 04:00 LOCAL" />

      {/* Adherence summary */}
      <div style={{ padding: '16px 20px' }}>
        <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>ADHERENCE</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
          <ScoreTile value={PROGRESS_METRICS.adherence.today} suffix="%" label="TODAY" tone="good" size="sm" />
          <ScoreTile value={PROGRESS_METRICS.adherence.week} suffix="%" label="7D" size="sm" />
          <ScoreTile value={PROGRESS_METRICS.adherence.month} suffix="%" label="30D" size="sm" />
          <ScoreTile value={PROGRESS_METRICS.adherence.streak} suffix="d" label="STREAK" tone="good" size="sm" />
        </div>
        <div style={{ marginTop: 14, background: 'var(--surface)', border: '1px solid var(--line)', padding: 12 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>CALENDAR · 12W</div>
            <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)' }}>{Icon.flame(10)} 23 DAY STREAK</div>
          </div>
          <Heatmap weeks={12} seed={42} />
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 4, marginTop: 8, alignItems: 'center' }}>
            <span className="mono" style={{ fontSize: 9, color: 'var(--fg-3)' }}>LESS</span>
            {['#13271C', '#1F3D2B', '#2A5A3E', '#3D7F56', '#4AA373'].map(c => <div key={c} style={{ width: 10, height: 10, background: c }} />)}
            <span className="mono" style={{ fontSize: 9, color: 'var(--fg-3)' }}>MORE</span>
          </div>
        </div>
      </div>

      {/* Metrics */}
      <div style={{ padding: '0 20px' }}>
        <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>METRICS</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--line)' }}>
          {metrics.map(m => (
            <div key={m.label} style={{ background: 'var(--bg)', padding: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>{m.label} · {m.unit}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
                  <div className="mono" style={{ fontSize: 22, fontWeight: 500 }}>{m.current}</div>
                  <div className="mono" style={{ fontSize: 11, color: m.good ? 'var(--verified)' : 'var(--bad)' }}>
                    {m.delta > 0 ? '↑' : '↓'} {Math.abs(m.delta)}
                  </div>
                </div>
              </div>
              <Sparkline data={m.data} w={120} h={36} />
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '16px 20px' }}>
        <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>INSIGHTS · AUTO</div>
        <div className="lb lb-accent" style={{ padding: '4px 0 4px 12px', marginBottom: 10 }}>
          <div className="mono" style={{ fontSize: 11, color: 'var(--fg-3)' }}>04/18</div>
          <div style={{ fontSize: 13, marginTop: 2 }}>HRV is trending +27% MoM — recovery load is well-managed.</div>
        </div>
        <div className="lb lb-warn" style={{ padding: '4px 0 4px 12px' }}>
          <div className="mono" style={{ fontSize: 11, color: 'var(--fg-3)' }}>04/15</div>
          <div style={{ fontSize: 13, marginTop: 2 }}>Sleep variance elevated on weekends (Δ 2.1h). Consider consistent window.</div>
        </div>
      </div>
    </div>
  );
}

// ─────────── Settings tab ───────────
function SettingsTab() {
  const rows = [
    ['PROFILE', [
      ['Name', 'Alex Morgan'],
      ['Age', '32'],
      ['Sex', 'Male'],
      ['Weight', '80.7 kg'],
      ['Height', '182 cm'],
    ]],
    ['HARD REQUIREMENTS', [
      ['Sleep window', '22:00 — 06:30'],
      ['Training days', 'Mon · Tue · Thu · Fri'],
      ['Work schedule', '09:00 — 18:00'],
      ['Dietary', 'No shellfish'],
    ]],
    ['WEIGHTED GOALS', [
      ['Muscle Gain', '0.85'],
      ['Longevity', '0.72'],
      ['Fat Loss', '0.30'],
      ['Sleep Quality', '0.60'],
    ]],
    ['INTEGRATIONS', [
      ['Apple Health', 'Connected'],
      ['Oura Ring', 'Connected'],
      ['Whoop', 'Not connected'],
    ]],
    ['ACCOUNT', [
      ['Email', 'alex@morgan.co'],
      ['Subscription', 'Maxim Pro · Annual'],
      ['Sign out', ''],
    ]],
  ];
  return (
    <div className="mf-scroll" style={{ height: '100%', overflowY: 'auto', paddingBottom: 100 }}>
      <MFHeader title="Settings" sub="ACCOUNT · PROFILE · PREFERENCES" />
      <div style={{ padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {rows.map(([label, items]) => (
          <div key={label}>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>{label}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--line)' }}>
              {items.map(([k, v]) => (
                <div key={k} style={{ background: 'var(--bg)', padding: '11px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ fontSize: 13 }}>{k}</div>
                  <div className="mono" style={{ fontSize: 12, color: 'var(--fg-2)' }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { MFHeader, ProtocolsTab, ChatTab, ProgressTab, SettingsTab });
