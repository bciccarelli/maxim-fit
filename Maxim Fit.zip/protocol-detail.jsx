// Maxim Fit — Protocol Detail screen with Verify / Modify / Ask / Versions
const { useState: useStateP, useEffect: useEffectP, useRef: useRefP, useMemo: useMemoP } = React;

function ProtocolDetail({ protocolId, layout='default', onBack }) {
  const p = PROTOCOLS.find(x => x.id === protocolId) || PROTOCOLS[0];
  const [tab, setTab] = useStateP('schedule');
  const [editName, setEditName] = useStateP(false);
  const [name, setName] = useStateP(p.name);
  const [verified, setVerified] = useStateP(p.verified);
  const [sheet, setSheet] = useStateP(null); // 'verify' | 'modify' | 'ask' | 'history' | 'sources'
  const [critiquesOpen, setCritiquesOpen] = useStateP(false);
  const [selectedCritiques, setSelectedCritiques] = useStateP([]);

  const tabs = [
    { k: 'schedule', label: 'Schedule' },
    { k: 'diet', label: 'Diet' },
    { k: 'supplements', label: 'Supp.' },
    { k: 'training', label: 'Training' },
  ];

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      {/* Top chrome */}
      <div style={{ padding: '10px 16px 0', borderBottom: '1px solid var(--line)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
          <button onClick={onBack} className="btn btn-ghost" style={{ padding: '6px 10px', display: 'flex', gap: 6, alignItems: 'center' }}>
            {Icon.chevLeft(12)} BACK
          </button>
          <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>PROTOCOL · {p.id.toUpperCase()}</div>
          <div style={{ flex: 1 }} />
          <button className="btn btn-ghost" style={{ padding: '6px 10px' }} onClick={() => setSheet('history')}>{Icon.history(12)}</button>
        </div>

        {/* Action bar */}
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 10 }}>
          <div style={{ flex: 1 }}>
            {editName ? (
              <input value={name} onChange={e => setName(e.target.value)} onBlur={() => setEditName(false)} autoFocus style={{ fontSize: 18, width: '100%', padding: '4px 6px' }} />
            ) : (
              <div onClick={() => setEditName(true)} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
                <div style={{ fontSize: 18, fontWeight: 500, letterSpacing: '-0.01em' }}>{name}</div>
                <span style={{ color: 'var(--fg-3)' }}>{Icon.edit(12)}</span>
              </div>
            )}
            <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 3 }}>V{p.version} · ALL REQUIREMENTS MET · {p.sources} SRC</div>
          </div>
          <VerifiedChip verified={verified} sources={p.sources} onClick={() => setSheet('sources')} />
        </div>

        {/* Scores */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 10 }}>
          <ScoreTile value={p.goalScore} label="GOAL SCORE" tone="good" />
          <ScoreTile value={p.viabilityScore} label="VIABILITY" tone="good" />
        </div>

        {/* Verify banner */}
        {!verified && (
          <div className="lb lb-warn" style={{ background: 'var(--surface)', padding: '10px 12px', marginBottom: 10, display: 'flex', gap: 10, alignItems: 'center' }}>
            <div style={{ flex: 1 }}>
              <div className="mono tracked-sm" style={{ color: 'var(--warn)' }}>UNVERIFIED</div>
              <div style={{ fontSize: 12, color: 'var(--fg-2)', marginTop: 2 }}>Run evidence check before acting on this protocol.</div>
            </div>
            <button className="btn btn-primary" onClick={() => setSheet('verify')} style={{ padding: '8px 12px' }}>VERIFY</button>
          </div>
        )}

        {/* Section tabs */}
        <div style={{ display: 'flex', gap: 0, marginTop: 4 }}>
          {tabs.map(t => (
            <button key={t.k} onClick={() => setTab(t.k)} className="mono" style={{
              flex: 1, padding: '10px 0', fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase',
              background: 'transparent', border: 'none', borderBottom: tab===t.k ? '2px solid var(--accent)' : '2px solid transparent',
              color: tab===t.k ? 'var(--fg)' : 'var(--fg-3)', cursor: 'pointer',
            }}>{t.label}</button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="mf-scroll" style={{ flex: 1, overflowY: 'auto', paddingBottom: 120 }}>
        {tab==='schedule' && <ScheduleView layout={layout} />}
        {tab==='diet' && <DietView />}
        {tab==='supplements' && <SupplementsView />}
        {tab==='training' && <TrainingView />}

        {/* Critiques */}
        <div style={{ padding: '16px 20px 0' }}>
          <div onClick={() => setCritiquesOpen(v => !v)} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', padding: '10px 0', borderTop: '1px solid var(--line)' }}>
            <div className="mono tracked-sm">CRITIQUES · {CRITIQUES.length}</div>
            <div style={{ transform: critiquesOpen ? 'rotate(90deg)' : 'none', color: 'var(--fg-3)' }}>{Icon.chevRight(12)}</div>
          </div>
          {critiquesOpen && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 12 }}>
              {CRITIQUES.map(c => {
                const sel = selectedCritiques.includes(c.id);
                const sevColor = c.sev==='high'?'var(--bad)':c.sev==='med'?'var(--warn)':'var(--fg-3)';
                return (
                  <div key={c.id} onClick={() => setSelectedCritiques(s => sel ? s.filter(x=>x!==c.id) : [...s, c.id])}
                    className="lb" style={{ borderLeftColor: sevColor, background: sel ? 'var(--surface-2)' : 'var(--surface)', padding: '10px 12px', cursor: 'pointer' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <div style={{ width: 12, height: 12, border: `1px solid ${sel?'var(--accent)':'var(--line-2)'}`, background: sel?'var(--accent)':'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        {sel && <span style={{ color: '#0A1711' }}>{Icon.check(8)}</span>}
                      </div>
                      <div className="mono tracked-sm" style={{ color: sevColor }}>{c.sev.toUpperCase()}</div>
                      <div style={{ fontSize: 13, fontWeight: 500, flex: 1 }}>{c.title}</div>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--fg-2)', lineHeight: 1.5, paddingLeft: 20 }}>{c.body}</div>
                  </div>
                );
              })}
              {selectedCritiques.length > 0 && (
                <div style={{ display: 'flex', gap: 6 }}>
                  <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setSelectedCritiques([])}>DISMISS</button>
                  <button className="btn btn-primary" style={{ flex: 2 }} onClick={() => { setSheet('modify'); setSelectedCritiques([]); }}>APPLY · {selectedCritiques.length}</button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Primary actions */}
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 84, padding: '10px 16px', background: 'linear-gradient(transparent, var(--bg) 30%)' }}>
        <div style={{ display: 'flex', gap: 6 }}>
          {!verified && <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setSheet('verify')}>VERIFY</button>}
          <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setSheet('ask')}>ASK</button>
          <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => setSheet('modify')}>MODIFY</button>
        </div>
      </div>

      {/* Sheets */}
      {sheet==='verify' && <VerifySheet onClose={() => setSheet(null)} onDone={() => { setVerified(true); setSheet(null); }} />}
      {sheet==='modify' && <ModifySheet onClose={() => setSheet(null)} />}
      {sheet==='ask' && <AskSheet onClose={() => setSheet(null)} onExport={() => setSheet('modify')} />}
      {sheet==='history' && <HistoryDrawer onClose={() => setSheet(null)} />}
      {sheet==='sources' && <SourcesDrawer onClose={() => setSheet(null)} count={p.sources} />}
    </div>
  );
}

// ─────────── Schedule view (timeline) ───────────
function ScheduleView({ layout='default' }) {
  const [expanded, setExpanded] = useStateP(null);
  const [editing, setEditing] = useStateP(null);
  if (layout === 'compact') return <ScheduleCompact expanded={expanded} setExpanded={setExpanded} />;
  return (
    <div style={{ padding: '14px 20px 4px' }}>
      <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 10 }}>MON 04/19 · 06:30 — 22:00</div>
      <div style={{ position: 'relative', paddingLeft: 56 }}>
        <div style={{ position: 'absolute', left: 50, top: 0, bottom: 0, width: 1, background: 'var(--line)' }} />
        {SCHEDULE.map((s, i) => {
          const isExp = expanded === i;
          const isEdit = editing === i;
          return (
            <div key={i} style={{ position: 'relative', marginBottom: 10 }}>
              <div className="mono" style={{ position: 'absolute', left: -56, top: 2, fontSize: 11, color: 'var(--fg-3)', width: 42, textAlign: 'right' }}>{s.t}</div>
              <div style={{ position: 'absolute', left: -10, top: 6, width: 7, height: 7, background: 'var(--accent)', border: '1px solid var(--bg)' }} />
              <div onClick={() => setExpanded(isExp ? null : i)} style={{ background: 'var(--surface)', border: '1px solid var(--line)', borderLeft: '2px solid var(--line-2)', padding: '8px 10px', cursor: 'pointer' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 6 }}>
                  <div style={{ fontSize: 13, fontWeight: 500, flex: 1, minWidth: 0 }}>{s.title}</div>
                  <div style={{ color: 'var(--fg-3)', transform: isExp?'rotate(90deg)':'none', transition: 'transform 120ms' }}>{Icon.chevRight(10)}</div>
                </div>
                {!isExp && <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 2 }}>{s.detail}</div>}
                {isExp && (
                  <div className="fade-in" style={{ marginTop: 8 }}>
                    {isEdit ? (
                      <textarea defaultValue={s.detail} style={{ width: '100%', minHeight: 60, fontSize: 12 }} />
                    ) : (
                      <div style={{ fontSize: 12, color: 'var(--fg-2)', lineHeight: 1.55 }}>{s.detail}</div>
                    )}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
                      <div className="mono" style={{ fontSize: 9, color: 'var(--fg-3)' }}>
                        {Array.from({length: Math.min(s.src, 5)}).map((_, ii) => (
                          <span key={ii} style={{ border: '1px solid var(--line-2)', padding: '1px 4px', marginRight: 2 }}>[{ii+1}]</span>
                        ))}
                        {s.src > 5 && <span>+{s.src-5}</span>}
                      </div>
                      <button onClick={(e)=>{ e.stopPropagation(); setEditing(isEdit?null:i); }} className="mono" style={{ background:'transparent', border:'1px solid var(--line-2)', color:'var(--fg-2)', fontSize: 10, padding: '4px 8px', cursor: 'pointer' }}>
                        {isEdit ? 'CONFIRM' : 'EDIT'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ScheduleCompact({ expanded, setExpanded }) {
  return (
    <div style={{ padding: '14px 20px' }}>
      <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 10 }}>MON 04/19 · COMPACT TABLE</div>
      <div style={{ border: '1px solid var(--line)' }}>
        {SCHEDULE.map((s, i) => (
          <div key={i} onClick={() => setExpanded(expanded===i?null:i)} style={{
            display: 'grid', gridTemplateColumns: '56px 1fr auto', gap: 10, alignItems: 'center',
            padding: '10px 12px', borderBottom: i<SCHEDULE.length-1?'1px solid var(--line)':'none', cursor: 'pointer',
            background: expanded===i ? 'var(--surface)' : 'transparent',
          }}>
            <div className="mono" style={{ fontSize: 11, color: 'var(--fg-3)' }}>{s.t}</div>
            <div style={{ fontSize: 13 }}>{s.title}</div>
            <div className="mono" style={{ fontSize: 9, color: 'var(--fg-3)' }}>{s.src} SRC</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────── Diet view ───────────
function DietView() {
  const t = DIET.targets;
  return (
    <div style={{ padding: '14px 20px' }}>
      <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>DAILY TARGETS</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 4, marginBottom: 14 }}>
        <ScoreTile value={t.kcal} label="KCAL" size="sm" />
        <ScoreTile value={t.p} suffix="g" label="PROTEIN" size="sm" />
        <ScoreTile value={t.c} suffix="g" label="CARBS" size="sm" />
        <ScoreTile value={t.f} suffix="g" label="FAT" size="sm" />
      </div>
      <div style={{ display: 'flex', gap: 4, marginBottom: 14 }}>
        <MacroBar label="P" value={t.p} target={t.p} color="var(--accent)" />
        <MacroBar label="C" value={t.c} target={t.c} color="#7a9f4f" />
        <MacroBar label="F" value={t.f} target={t.f} color="#c8a84f" />
      </div>
      <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>MEALS · 3</div>
      {DIET.meals.map((m, i) => (
        <div key={i} style={{ marginBottom: 12, border: '1px solid var(--line)', borderLeft: '2px solid var(--line-2)' }}>
          <div style={{ padding: '8px 12px', background: 'var(--surface)', display: 'flex', justifyContent: 'space-between' }}>
            <div>
              <div className="mono" style={{ fontSize: 11, color: 'var(--fg-3)' }}>{m.time}</div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{m.name}</div>
            </div>
            <div className="mono" style={{ fontSize: 11, color: 'var(--fg-2)', textAlign: 'right' }}>
              {m.items.reduce((a, x) => a+x.kcal, 0)} kcal<br/>
              <span style={{ color: 'var(--fg-3)', fontSize: 9 }}>P {m.items.reduce((a,x)=>a+x.p,0)}g · C {m.items.reduce((a,x)=>a+x.c,0)}g · F {m.items.reduce((a,x)=>a+x.f,0)}g</span>
            </div>
          </div>
          {m.items.map((x, j) => (
            <div key={j} style={{ padding: '8px 12px', borderTop: '1px solid var(--line)', display: 'grid', gridTemplateColumns: '56px 1fr auto', gap: 8, alignItems: 'center' }}>
              <div className="mono" style={{ fontSize: 11, color: 'var(--fg-2)' }}>{x.q}</div>
              <div style={{ fontSize: 12 }}>{x.name}</div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)' }}>{x.kcal}</div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function MacroBar({ label, value, target, color }) {
  const pct = Math.min(100, (value/target)*100);
  return (
    <div style={{ flex: 1 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
        <span className="mono" style={{ fontSize: 9, color: 'var(--fg-3)' }}>{label}</span>
        <span className="mono" style={{ fontSize: 9, color: 'var(--fg-2)' }}>{value}g</span>
      </div>
      <div style={{ height: 3, background: 'var(--line)' }}>
        <div style={{ height: '100%', width: pct+'%', background: color }} />
      </div>
    </div>
  );
}

// ─────────── Supplements ───────────
function SupplementsView() {
  const evColor = e => e==='A'?'var(--verified)':e==='B'?'var(--warn)':'var(--fg-3)';
  return (
    <div style={{ padding: '14px 20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>STACK · {SUPPLEMENTS.length}</div>
        <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)' }}>EVIDENCE · A/B/C</div>
      </div>
      <div style={{ border: '1px solid var(--line)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '48px 1fr 70px 20px', gap: 8, padding: '8px 12px', background: 'var(--surface)', borderBottom: '1px solid var(--line-2)' }}>
          <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>TIME</div>
          <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>COMPOUND</div>
          <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', textAlign: 'right' }}>DOSE</div>
          <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>EV</div>
        </div>
        {SUPPLEMENTS.map((s, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '48px 1fr 70px 20px', gap: 8, padding: '10px 12px', borderBottom: i<SUPPLEMENTS.length-1?'1px solid var(--line)':'none', alignItems: 'center' }}>
            <div className="mono" style={{ fontSize: 11, color: 'var(--fg-3)' }}>{s.time}</div>
            <div>
              <div style={{ fontSize: 13 }}>{s.name}</div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 1 }}>{s.form} · w/ {s.with}</div>
            </div>
            <div className="mono" style={{ fontSize: 12, textAlign: 'right' }}>{s.dose}</div>
            <div className="mono" style={{ fontSize: 11, color: evColor(s.evidence), fontWeight: 600 }}>{s.evidence}</div>
          </div>
        ))}
      </div>
      <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 10, lineHeight: 1.6 }}>
        <div>A · Multiple RCTs, strong effect</div>
        <div>B · Limited RCTs, moderate effect</div>
        <div>C · Mechanistic or observational</div>
      </div>
    </div>
  );
}

// ─────────── Training ───────────
function TrainingView() {
  const [dayIdx, setDayIdx] = useStateP(0);
  const day = TRAINING[dayIdx];
  return (
    <div style={{ padding: '14px 20px' }}>
      <div style={{ display: 'flex', gap: 4, marginBottom: 12, overflow: 'auto' }}>
        {TRAINING.map((d, i) => (
          <button key={i} onClick={() => setDayIdx(i)} className="mono" style={{
            padding: '6px 10px', fontSize: 11, letterSpacing: '0.08em',
            background: dayIdx===i?'var(--surface-2)':'transparent',
            border: `1px solid ${dayIdx===i?'var(--accent)':'var(--line)'}`,
            color: dayIdx===i?'var(--fg)':'var(--fg-2)', cursor: 'pointer',
          }}>{d.day.toUpperCase()}</button>
        ))}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 }}>
        <div style={{ fontSize: 16, fontWeight: 500 }}>{day.block}</div>
        <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)' }}>{day.exercises.length} MOVEMENTS · ~60 MIN</div>
      </div>
      <div style={{ border: '1px solid var(--line)' }}>
        {day.exercises.map((e, i) => (
          <div key={i} style={{ padding: '12px', borderBottom: i<day.exercises.length-1?'1px solid var(--line)':'none', display: 'grid', gridTemplateColumns: '24px 1fr auto', gap: 10, alignItems: 'center' }}>
            <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)' }}>{String(i+1).padStart(2,'0')}</div>
            <div>
              <div style={{ fontSize: 13 }}>{e.name}</div>
              <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 2 }}>{e.load} · RIR {e.rir}</div>
            </div>
            <div className="mono" style={{ fontSize: 13, color: 'var(--fg)', textAlign: 'right' }}>
              {e.sets}<span style={{ color: 'var(--fg-3)' }}> × </span>{e.reps}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ProtocolDetail, ScheduleView, DietView, SupplementsView, TrainingView });
