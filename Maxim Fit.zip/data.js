// Maxim Fit — sample data

const PROTOCOLS = [
  {
    id: 'p_01',
    name: 'Muscle Gain · Longevity',
    goals: ['Muscle Gain', 'Longevity'],
    goalScore: 87,
    viabilityScore: 92,
    verified: true,
    sources: 34,
    createdAt: '2026-03-14',
    version: 4,
    summary: '5-day push/pull/legs split with creatine, omega-3, Zone 2 cardio, 16:8 feeding window.',
  },
  {
    id: 'p_02',
    name: 'Fat Loss · Energy',
    goals: ['Fat Loss', 'Energy'],
    goalScore: 74,
    viabilityScore: 81,
    verified: true,
    sources: 22,
    createdAt: '2026-02-28',
    version: 2,
    summary: 'Moderate deficit (−450 kcal), high protein, 10k steps, resistance 3x/wk, caffeine cutoff 14:00.',
  },
  {
    id: 'p_03',
    name: 'Sleep Quality · Recovery',
    goals: ['Sleep Quality', 'Recovery'],
    goalScore: 91,
    viabilityScore: 88,
    verified: false,
    sources: 18,
    createdAt: '2026-04-08',
    version: 1,
    summary: 'Magnesium glycinate, glycine pre-bed, consistent 23:00–07:00 window, morning sunlight protocol.',
  },
  {
    id: 'p_04',
    name: 'Endurance · Cardiovascular',
    goals: ['Endurance', 'Cardiovascular'],
    goalScore: 79,
    viabilityScore: 85,
    verified: true,
    sources: 28,
    createdAt: '2026-01-20',
    version: 3,
    summary: 'Polarized 80/20 Zone 2/threshold, 5 sessions/wk, beta-alanine, iron monitoring.',
  },
];

const SCHEDULE = [
  { t: '06:30', kind: 'wake', title: 'Wake · 500ml water + electrolytes', detail: 'Na 500mg · K 300mg · Mg 200mg', src: 4 },
  { t: '06:45', kind: 'light', title: 'Sunlight exposure · 10 min', detail: 'Outdoors, no sunglasses. Circadian anchor.', src: 6 },
  { t: '07:15', kind: 'supplement', title: 'AM Stack', detail: 'Vit D3 5000IU · K2 100mcg · Omega-3 2g', src: 9 },
  { t: '08:00', kind: 'meal', title: 'Meal 1 · Protein-forward', detail: '4 eggs · 80g oats · berries · 45g protein', src: 5 },
  { t: '10:30', kind: 'work', title: 'Deep work block', detail: '90 min focus · no food, water only', src: 2 },
  { t: '12:30', kind: 'meal', title: 'Meal 2 · Lunch', detail: '200g chicken · 150g rice · greens · 55g protein', src: 3 },
  { t: '14:00', kind: 'cutoff', title: 'Caffeine cutoff', detail: 'No caffeine past this point. Half-life ≈ 6h.', src: 7 },
  { t: '17:00', kind: 'train', title: 'Training · Push (chest/shoulders/tri)', detail: '5 compound lifts · 60 min', src: 8 },
  { t: '18:30', kind: 'meal', title: 'Meal 3 · Post-workout', detail: '250g salmon · sweet potato · 50g protein', src: 4 },
  { t: '20:30', kind: 'wind', title: 'Wind-down · Dim lights', detail: 'No screens, magnesium glycinate 400mg', src: 6 },
  { t: '22:00', kind: 'sleep', title: 'Sleep', detail: '8h window · 22:00–06:30', src: 5 },
];

const DIET = {
  targets: { kcal: 2850, p: 185, c: 220, f: 65, fiber: 38, water: 3.5 },
  meals: [
    { time: '08:00', name: 'Meal 1 — Breakfast', items: [
      { q: '4', unit: 'whole', name: 'eggs, pastured', kcal: 280, p: 24, c: 2, f: 20 },
      { q: '80g', unit: '', name: 'rolled oats', kcal: 300, p: 10, c: 54, f: 5 },
      { q: '150g', unit: '', name: 'mixed berries', kcal: 75, p: 1, c: 18, f: 0 },
    ]},
    { time: '12:30', name: 'Meal 2 — Lunch', items: [
      { q: '200g', unit: '', name: 'chicken breast', kcal: 330, p: 62, c: 0, f: 7 },
      { q: '150g', unit: 'cooked', name: 'jasmine rice', kcal: 195, p: 4, c: 42, f: 0 },
      { q: '200g', unit: '', name: 'mixed greens + olive oil', kcal: 140, p: 2, c: 6, f: 12 },
    ]},
    { time: '18:30', name: 'Meal 3 — Dinner', items: [
      { q: '250g', unit: '', name: 'wild salmon', kcal: 520, p: 50, c: 0, f: 34 },
      { q: '300g', unit: '', name: 'sweet potato, roasted', kcal: 260, p: 4, c: 60, f: 0 },
      { q: '150g', unit: '', name: 'asparagus', kcal: 30, p: 3, c: 6, f: 0 },
    ]},
  ],
};

const SUPPLEMENTS = [
  { time: '07:15', name: 'Vitamin D3', dose: '5000 IU', form: 'softgel', with: 'fat', evidence: 'A', src: 12 },
  { time: '07:15', name: 'Vitamin K2 (MK-7)', dose: '100 mcg', form: 'softgel', with: 'D3', evidence: 'B', src: 6 },
  { time: '07:15', name: 'Omega-3 (EPA/DHA)', dose: '2 g', form: 'softgel', with: 'food', evidence: 'A', src: 22 },
  { time: '07:15', name: 'Creatine Monohydrate', dose: '5 g', form: 'powder', with: 'anything', evidence: 'A', src: 18 },
  { time: '12:30', name: 'Magnesium Glycinate', dose: '200 mg', form: 'capsule', with: 'meal', evidence: 'B', src: 9 },
  { time: '20:30', name: 'Magnesium Glycinate', dose: '200 mg', form: 'capsule', with: 'pre-bed', evidence: 'B', src: 9 },
  { time: '20:30', name: 'Glycine', dose: '3 g', form: 'powder', with: 'pre-bed', evidence: 'B', src: 4 },
];

const TRAINING = [
  { day: 'Mon', block: 'Push', exercises: [
    { name: 'Barbell Bench Press', sets: 4, reps: '6–8', rir: 2, load: '100 kg' },
    { name: 'Overhead Press', sets: 3, reps: '8–10', rir: 2, load: '55 kg' },
    { name: 'Incline DB Press', sets: 3, reps: '10–12', rir: 1, load: '32 kg' },
    { name: 'Lateral Raise', sets: 3, reps: '12–15', rir: 0, load: '12 kg' },
    { name: 'Tricep Pushdown', sets: 3, reps: '12–15', rir: 0, load: '30 kg' },
  ]},
  { day: 'Tue', block: 'Pull', exercises: [
    { name: 'Deadlift', sets: 3, reps: '4–6', rir: 2, load: '160 kg' },
    { name: 'Weighted Pull-up', sets: 4, reps: '6–8', rir: 2, load: '+15 kg' },
    { name: 'Barbell Row', sets: 3, reps: '8–10', rir: 1, load: '85 kg' },
    { name: 'Face Pull', sets: 3, reps: '15', rir: 0, load: '25 kg' },
    { name: 'Hammer Curl', sets: 3, reps: '10–12', rir: 0, load: '18 kg' },
  ]},
  { day: 'Wed', block: 'Zone 2 Cardio', exercises: [
    { name: 'Zone 2 Bike', sets: 1, reps: '45 min', rir: 0, load: 'HR 132–142' },
  ]},
  { day: 'Thu', block: 'Legs', exercises: [
    { name: 'Back Squat', sets: 4, reps: '6–8', rir: 2, load: '130 kg' },
    { name: 'Romanian Deadlift', sets: 3, reps: '8–10', rir: 2, load: '110 kg' },
    { name: 'Bulgarian Split Squat', sets: 3, reps: '10/leg', rir: 1, load: '22 kg' },
    { name: 'Leg Curl', sets: 3, reps: '12', rir: 0, load: '45 kg' },
    { name: 'Standing Calf Raise', sets: 4, reps: '12–15', rir: 0, load: '80 kg' },
  ]},
  { day: 'Fri', block: 'Upper', exercises: [
    { name: 'Weighted Dip', sets: 4, reps: '8', rir: 2, load: '+20 kg' },
    { name: 'Chest-Supported Row', sets: 4, reps: '10', rir: 1, load: '60 kg' },
    { name: 'Arnold Press', sets: 3, reps: '10', rir: 1, load: '22 kg' },
    { name: 'Cable Fly', sets: 3, reps: '12', rir: 0, load: '18 kg' },
  ]},
];

const CRITIQUES = [
  { id: 'c1', sev: 'med', title: 'Protein distribution uneven', body: 'Meal 3 delivers 50g but Meal 1 only 35g. Spread boluses ≥30g every 3–4h for leucine threshold (Schoenfeld 2018).', src: 3 },
  { id: 'c2', sev: 'low', title: 'K2 dose below optimal', body: 'Current 100mcg MK-7. Emerging data suggests 180–360mcg for arterial calcification markers.', src: 4 },
  { id: 'c3', sev: 'high', title: 'No deload scheduled', body: '8 weeks without a programmed deload. Consider week 9 at 60% volume to manage CNS fatigue.', src: 6 },
];

const SOURCES = [
  { id: 1, author: 'Schoenfeld BJ, Aragon AA', year: 2018, title: 'How much protein can the body use in a single meal', journal: 'J Int Soc Sports Nutr', doi: '10.1186/s12970-018-0215-1' },
  { id: 2, author: 'Morton RW et al.', year: 2018, title: 'A systematic review, meta-analysis and meta-regression of the effect of protein supplementation on resistance training-induced gains in muscle mass and strength in healthy adults', journal: 'Br J Sports Med', doi: '10.1136/bjsports-2017-097608' },
  { id: 3, author: 'Helms ER et al.', year: 2014, title: 'Evidence-based recommendations for natural bodybuilding contest preparation: nutrition and supplementation', journal: 'J Int Soc Sports Nutr', doi: '10.1186/1550-2783-11-20' },
  { id: 4, author: 'Kreider RB et al.', year: 2017, title: 'Safety and efficacy of creatine supplementation in exercise, sport, and medicine', journal: 'J Int Soc Sports Nutr', doi: '10.1186/s12970-017-0173-z' },
  { id: 5, author: 'Walker MP', year: 2017, title: 'Why We Sleep', journal: 'Scribner', doi: '—' },
  { id: 6, author: 'Hazell TJ et al.', year: 2014, title: 'Running sprint interval training induces fat loss in women', journal: 'Appl Physiol Nutr Metab', doi: '10.1139/apnm-2013-0503' },
  { id: 7, author: 'Drake C et al.', year: 2013, title: 'Caffeine effects on sleep taken 0, 3, or 6 hours before going to bed', journal: 'J Clin Sleep Med', doi: '10.5664/jcsm.3170' },
  { id: 8, author: 'Grgic J et al.', year: 2018, title: 'Effects of resistance training frequency on gains in muscular strength', journal: 'Sports Med', doi: '10.1007/s40279-018-0872-x' },
];

const CHAT_HISTORY = [
  { id: 1, role: 'user', text: 'Is creatine safe long-term?' },
  { id: 2, role: 'ai', text: 'Yes — creatine monohydrate has one of the strongest safety profiles of any supplement studied. Meta-analyses covering 5+ years of continuous use show no adverse effects on renal function, hepatic markers, or body composition in healthy adults. The 5g/day maintenance dose is well-supported across 1000+ RCTs.', sources: [4, 2] },
  { id: 3, role: 'user', text: 'Should I cycle off?' },
  { id: 4, role: 'ai', text: 'No cycling needed. Unlike some ergogenic aids, creatine does not downregulate endogenous synthesis in a way that causes rebound issues. Continuous use maintains saturated muscle stores (~160mmol/kg dry weight), which is the mechanism behind its performance benefits.', sources: [4] },
];

const PROGRESS_METRICS = {
  adherence: { today: 94, week: 89, month: 87, streak: 23 },
  weight: [82.1, 82.3, 82.0, 81.8, 81.9, 81.6, 81.5, 81.4, 81.2, 81.3, 81.0, 80.8, 80.9, 80.7],
  sleep: [7.2, 6.8, 7.5, 8.1, 7.8, 7.4, 8.2, 7.9, 7.6, 8.0, 7.5, 8.1, 7.8, 8.3],
  bench: [90, 92.5, 92.5, 95, 95, 97.5, 97.5, 100, 100, 100, 102.5, 102.5, 102.5, 105],
  hrv: [52, 55, 48, 61, 58, 54, 63, 60, 57, 62, 59, 64, 61, 66],
};

Object.assign(window, { PROTOCOLS, SCHEDULE, DIET, SUPPLEMENTS, TRAINING, CRITIQUES, SOURCES, CHAT_HISTORY, PROGRESS_METRICS });
