// Maxim Fit — Sheets: Verify, Modify, Ask, History, Sources
const { useState: useStateS, useEffect: useEffectS, useRef: useRefS } = React;

// ─────────── Shared sheet shell ───────────
function Sheet({ title, onClose, children, footer, variant='modal' }) {
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 100, display: 'flex', flexDirection: 'column', background: 'rgba(5, 12, 8, 0.72)', backdropFilter: 'blur(4px)' }} onClick={onClose}>
      <div style={{ flex: 1 }} />
      <div onClick={e => e.stopPropagation()} className="slide-up" style={{ background: 'var(--bg)', borderTop: '1px solid var(--line-2)', maxHeight: variant==='full'?'94%':'82%', display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderBottom: '1px solid var(--line)' }}>
          <div className="mono tracked-sm" style={{ color: 'var(--fg)' }}>{title}</div>
          <button onClick={onClose} style={{ background: 'transparent', border: '1px solid var(--line-2)', color: 'var(--fg-2)', padding: 6, cursor: 'pointer' }}>{Icon.close(12)}</button>
        </div>
        <div className="mf-scroll" style={{ flex: 1, overflowY: 'auto' }}>{children}</div>
        {footer && <div style={{ padding: '10px 16px 28px', borderTop: '1px solid var(--line)', background: 'var(--bg-2)' }}>{footer}</div>}
      </div>
    </div>
  );
}

// ─────────── Verify Sheet ───────────
function VerifySheet({ onClose, onDone }) {
  const stages = [
    { label: 'SEARCHING LITERATURE', sub: 'Querying PubMed · Cochrane · bioRxiv…' },
    { label: 'CROSS-REFERENCING', sub: 'Matching claims ↔ citations · 34 candidates' },
    { label: 'EVALUATING EVIDENCE', sub: 'Grading by study type, N, effect size' },
  ];
  const [active, setActive] = useStateS(0);
  const [done, setDone] = useStateS([]);
  const [complete, setComplete] = useStateS(false);

  useEffectS(() => {
    if (complete) return;
    const timers = [
      setTimeout(() => { setDone([0]); setActive(1); }, 1400),
      setTimeout(() => { setDone([0,1]); setActive(2); }, 2800),
      setTimeout(() => { setDone([0,1,2]); setActive(-1); setComplete(true); }, 4200),
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <Sheet title={complete ? 'VERIFICATION · COMPLETE' : 'VERIFYING PROTOCOL'} onClose={onClose}
      footer={complete && <button className="btn btn-primary" style={{ width: '100%' }} onClick={onDone}>ACCEPT · MARK VERIFIED</button>}>
      <div style={{ padding: 16 }}>
        <StreamingStages stages={stages} active={active} done={done} />
        {complete && (
          <div className="fade-in" style={{ marginTop: 18 }}>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>RESULT</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 12 }}>
              <ScoreTile value={34} label="SOURCES FOUND" tone="good" />
              <ScoreTile value={'A-'} label="EVIDENCE GRADE" tone="good" />
            </div>
            <div className="lb lb-accent" style={{ padding: 10, background: 'var(--surface)' }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>All primary claims supported</div>
              <div style={{ fontSize: 12, color: 'var(--fg-2)', marginTop: 4, lineHeight: 1.5 }}>
                34 citations · 22 RCTs · 8 meta-analyses · 4 observational. 2 recommendations flagged as "mechanistic only" — see Critiques.
              </div>
            </div>
          </div>
        )}
      </div>
    </Sheet>
  );
}

// ─────────── Modify Sheet ───────────
function ModifySheet({ onClose }) {
  const [prompt, setPrompt] = useStateS('');
  const [phase, setPhase] = useStateS('input'); // input | research | apply | result
  const [reasoning, setReasoning] = useStateS('');
  const [scoreDiff, setScoreDiff] = useStateS(null);

  function run() {
    if (!prompt.trim()) return;
    setPhase('research');
    const text = `Analyzing request: "${prompt}". Retrieved 14 relevant studies. Leucine threshold per meal is 2.5–3g, typically hit with ~30g quality protein. Current Meal 1 delivers 35g — adequate. Meal 2: 66g (abundant). Meal 3: 57g. Inter-meal gaps 4.5h / 6h are within the 3–5h ideal window...`;
    let i = 0;
    const iv = setInterval(() => {
      i += 3;
      if (i >= text.length) { clearInterval(iv); setReasoning(text); setPhase('apply'); setTimeout(applyChanges, 900); }
      else setReasoning(text.slice(0, i));
    }, 18);
  }

  function applyChanges() {
    setScoreDiff({ goal: { from: 87, to: 91 }, via: { from: 92, to: 90 } });
    setPhase('result');
  }

  const footer = phase==='input' ? (
    <button className="btn btn-primary" style={{ width: '100%' }} onClick={run} disabled={!prompt.trim()}>GENERATE MODIFICATIONS</button>
  ) : phase==='result' ? (
    <div style={{ display: 'flex', gap: 6 }}>
      <button className="btn btn-ghost" style={{ flex: 1 }} onClick={onClose}>REJECT</button>
      <button className="btn btn-primary" style={{ flex: 2 }} onClick={onClose}>ACCEPT · NEW VERSION</button>
    </div>
  ) : null;

  return (
    <Sheet title={`MODIFY · ${phase.toUpperCase()}`} onClose={onClose} footer={footer} variant="full">
      <div style={{ padding: 16 }}>
        {phase==='input' && (
          <div>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>WHAT SHOULD CHANGE?</div>
            <textarea autoFocus value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="e.g., Move training to mornings. Add more protein to Meal 1."
              style={{ width: '100%', minHeight: 110, fontSize: 14 }} />
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', margin: '16px 0 8px' }}>QUICK INTENTS</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {['More protein per meal', 'Shift training to AM', 'Reduce caffeine', 'Add deload week'].map(q => (
                <div key={q} onClick={() => setPrompt(q)} className="mono" style={{ fontSize: 12, padding: 10, border: '1px solid var(--line)', cursor: 'pointer', color: 'var(--fg-2)' }}>→ {q}</div>
              ))}
            </div>
          </div>
        )}
        {(phase==='research' || phase==='apply') && (
          <div>
            <StreamingStages
              stages={[
                { label: 'RESEARCHING', sub: 'Retrieval-augmented lookup across 14 sources' },
                { label: 'APPLYING', sub: 'Reconciling against your hard requirements' },
              ]}
              active={phase==='research'?0:1}
              done={phase==='apply'?[0]:[]}
            />
            <div className="lb" style={{ marginTop: 16, padding: '2px 0 2px 12px' }}>
              <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 4 }}>REASONING</div>
              <div style={{ fontSize: 12, color: 'var(--fg-2)', lineHeight: 1.6 }}>
                {reasoning}{phase==='research' && <span className="caret" style={{ marginLeft: 2, background: 'var(--accent)', width: 6, height: 12, display: 'inline-block', verticalAlign: 'middle' }} />}
              </div>
            </div>
          </div>
        )}
        {phase==='result' && scoreDiff && (
          <div className="fade-in">
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>SCORE · DELTA</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 14 }}>
              <ScoreDelta label="GOAL" from={scoreDiff.goal.from} to={scoreDiff.goal.to} />
              <ScoreDelta label="VIABILITY" from={scoreDiff.via.from} to={scoreDiff.via.to} />
            </div>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>CHANGES · 3</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { t: 'MEAL 1', d: '+15g protein via Greek yogurt 200g', delta: '+' },
                { t: 'MEAL 2', d: 'Shift from 12:30 → 13:00 for training recovery', delta: '~' },
                { t: 'SUPPLEMENTS', d: 'Add leucine 2g pre-workout (evidence B)', delta: '+' },
              ].map((c, i) => (
                <div key={i} className="lb lb-accent" style={{ padding: '8px 12px', background: 'var(--surface)' }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <div className="mono" style={{ width: 16, color: 'var(--accent)' }}>{c.delta}</div>
                    <div className="mono tracked-sm" style={{ color: 'var(--fg-3)' }}>{c.t}</div>
                  </div>
                  <div style={{ fontSize: 13, marginTop: 4, paddingLeft: 24 }}>{c.d}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Sheet>
  );
}

function ScoreDelta({ label, from, to }) {
  const up = to >= from;
  return (
    <div className="tile">
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
        <span className="mono" style={{ fontSize: 14, color: 'var(--fg-3)', textDecoration: 'line-through' }}>{from}</span>
        <span style={{ color: 'var(--fg-3)' }}>→</span>
        <span className="mono" style={{ fontSize: 24, fontWeight: 500, color: up?'var(--verified)':'var(--bad)' }}>{to}</span>
        <span className="mono" style={{ fontSize: 11, color: up?'var(--verified)':'var(--bad)' }}>{up?'+':'−'}{Math.abs(to-from)}</span>
      </div>
      <div className="score-label">{label}</div>
    </div>
  );
}

// ─────────── Ask Sheet ───────────
function AskSheet({ onClose, onExport }) {
  const [q, setQ] = useStateS('');
  const [answer, setAnswer] = useStateS('');
  const [streaming, setStreaming] = useStateS(false);
  const [done, setDone] = useStateS(false);

  function ask() {
    if (!q.trim()) return;
    setStreaming(true); setDone(false); setAnswer('');
    const text = `Your Meal 1 is front-loaded with eggs and oats at 08:00 because morning protein intake drives cortisol normalization and anchors circadian satiety signaling. The 4-egg choice specifically provides 1.6g leucine — just above threshold — plus choline for acetylcholine synthesis. If you prefer a leaner option, 200g egg whites + 40g whey delivers equivalent leucine at 40% fewer calories.`;
    let i = 0;
    const iv = setInterval(() => {
      i += 3;
      if (i >= text.length) { clearInterval(iv); setAnswer(text); setStreaming(false); setDone(true); }
      else setAnswer(text.slice(0, i));
    }, 18);
  }

  return (
    <Sheet title="ASK · PROTOCOL Q&A" onClose={onClose}
      footer={done && <button className="btn btn-primary" style={{ width: '100%' }} onClick={onExport}>EXPORT TO MODIFY →</button>}>
      <div style={{ padding: 16 }}>
        {!streaming && !done && (
          <>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 8 }}>YOUR QUESTION</div>
            <textarea autoFocus value={q} onChange={e => setQ(e.target.value)} placeholder="e.g., Why is Meal 1 the way it is?" style={{ width: '100%', minHeight: 90, fontSize: 14 }} />
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', margin: '14px 0 8px' }}>SUGGESTED</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {['Why Meal 1 the way it is?', 'Why creatine at this dose?', 'Is Zone 2 better than HIIT for me?'].map(s => (
                <div key={s} onClick={() => setQ(s)} className="mono" style={{ fontSize: 12, padding: 10, border: '1px solid var(--line)', cursor: 'pointer', color: 'var(--fg-2)' }}>→ {s}</div>
              ))}
            </div>
            <button className="btn btn-primary" style={{ width: '100%', marginTop: 14 }} onClick={ask} disabled={!q.trim()}>ASK</button>
          </>
        )}
        {(streaming || done) && (
          <>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 6 }}>Q</div>
            <div style={{ fontSize: 14, marginBottom: 14, color: 'var(--fg)' }}>{q}</div>
            <div className="mono tracked-sm" style={{ color: 'var(--fg-3)', marginBottom: 6 }}>A {streaming && <span className="pulse" style={{ color: 'var(--accent)' }}>STREAMING</span>}</div>
            <div className="lb lb-accent" style={{ padding: '2px 0 2px 12px' }}>
              <div style={{ fontSize: 14, lineHeight: 1.6 }}>
                {answer}{streaming && <span className="caret" style={{ marginLeft: 2, background: 'var(--accent)', width: 7, height: 14, display: 'inline-block', verticalAlign: 'middle' }} />}
              </div>
            </div>
            {done && (
              <div style={{ display: 'flex', gap: 4, marginTop: 10, flexWrap: 'wrap' }}>
                {[3, 1, 2].map(s => (
                  <span key={s} className="mono" style={{ fontSize: 9, color: 'var(--fg-3)', border: '1px solid var(--line)', padding: '3px 6px' }}>[{s}] {SOURCES[s-1]?.author.split(' ')[0]}·{SOURCES[s-1]?.year}</span>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </Sheet>
  );
}

// ─────────── History drawer ───────────
function HistoryDrawer({ onClose }) {
  const versions = [
    { v: 4, date: '2026-04-15', note: 'Tuned Meal 2 carbs + added glycine', current: true, goal: 87, via: 92 },
    { v: 3, date: '2026-04-02', note: 'Added Zone 2 Wednesday · K2 dose', goal: 83, via: 90 },
    { v: 2, date: '2026-03-24', note: 'Shifted training to 17:00', goal: 78, via: 88 },
    { v: 1, date: '2026-03-14', note: 'Initial generation', goal: 72, via: 82 },
  ];
  return (
    <Sheet title="VERSION HISTORY" onClose={onClose}>
      <div style={{ padding: 16 }}>
        <div style={{ position: 'relative', paddingLeft: 20 }}>
          <div style={{ position: 'absolute', left: 4, top: 6, bottom: 6, width: 1, background: 'var(--line-2)' }} />
          {versions.map((v, i) => (
            <div key={v.v} style={{ position: 'relative', marginBottom: 14 }}>
              <div style={{ position: 'absolute', left: -20, top: 4, width: 9, height: 9, background: v.current?'var(--accent)':'var(--bg)', border: `1px solid ${v.current?'var(--accent)':'var(--line-2)'}` }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div className="mono" style={{ fontSize: 13, fontWeight: 500 }}>V{v.v}</div>
                    {v.current && <span className="chip chip-verified" style={{ fontSize: 9, padding: '1px 5px' }}>CURRENT</span>}
                    <span className="mono" style={{ fontSize: 10, color: 'var(--fg-3)' }}>{v.date}</span>
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--fg-2)', marginTop: 4 }}>{v.note}</div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 4 }}>GOAL {v.goal} · VIA {v.via}</div>
                </div>
                {!v.current && (
                  <button className="btn btn-ghost" style={{ padding: '4px 8px', fontSize: 10 }}>REVERT</button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Sheet>
  );
}

// ─────────── Sources drawer ───────────
function SourcesDrawer({ onClose, count }) {
  return (
    <Sheet title={`SOURCES · ${count}`} onClose={onClose}>
      <div style={{ padding: 16 }}>
        <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
          <ScoreTile value={22} label="RCT" tone="good" size="sm" />
          <ScoreTile value={8} label="META" tone="good" size="sm" />
          <ScoreTile value={4} label="OBS" size="sm" />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--line)' }}>
          {SOURCES.map(s => (
            <div key={s.id} style={{ background: 'var(--bg)', padding: 12 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 }}>
                <div className="mono" style={{ fontSize: 11, color: 'var(--accent)', minWidth: 22 }}>[{s.id}]</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, lineHeight: 1.4 }}>{s.title}</div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 4 }}>{s.author} · {s.year} · {s.journal}</div>
                  <div className="mono" style={{ fontSize: 10, color: 'var(--fg-3)', marginTop: 2 }}>doi: {s.doi}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Sheet>
  );
}

// ─────────── Generating screen (pre-first protocol) ───────────
function GeneratingScreen({ onDone, onBack }) {
  const stages = [
    { label: 'SEARCHING', sub: 'Pulling literature across your weighted goals' },
    { label: 'GENERATING', sub: 'Drafting schedule · diet · supplements · training' },
    { label: 'EVALUATING', sub: 'Scoring against your hard requirements' },
  ];
  const [active, setActive] = useStateS(0);
  const [done, setDone] = useStateS([]);
  const [complete, setComplete] = useStateS(false);
  useEffectS(() => {
    const t = [
      setTimeout(() => { setDone([0]); setActive(1); }, 1500),
      setTimeout(() => { setDone([0,1]); setActive(2); }, 3100),
      setTimeout(() => { setDone([0,1,2]); setActive(-1); setComplete(true); }, 4600),
    ];
    return () => t.forEach(clearTimeout);
  }, []);
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
      <div style={{ padding: '14px 20px 0' }}>
        <button onClick={onBack} className="btn btn-ghost" style={{ padding: '6px 10px', display: 'flex', gap: 6, alignItems: 'center' }}>
          {Icon.chevLeft(12)} CANCEL
        </button>
      </div>
      <div style={{ flex: 1, padding: '28px 20px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <div className="mono tracked-sm" style={{ color: 'var(--accent)', marginBottom: 6 }}>MAXIM · FIT</div>
        <div style={{ fontSize: 24, fontWeight: 500, marginBottom: 8, letterSpacing: '-0.02em' }}>
          {complete ? 'Protocol ready.' : 'Generating your protocol…'}
        </div>
        <div className="mono" style={{ fontSize: 12, color: 'var(--fg-3)', marginBottom: 24 }}>
          {complete ? 'Opens in a moment.' : 'Staged generation · 3–8 seconds'}
        </div>
        <StreamingStages stages={stages} active={active} done={done} />
        {complete && (
          <div className="fade-in" style={{ marginTop: 22, display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6 }}>
            <ScoreTile value={87} label="GOAL" tone="good" />
            <ScoreTile value={92} label="VIABILITY" tone="good" />
            <ScoreTile value={34} label="SOURCES" tone="good" />
          </div>
        )}
      </div>
      {complete && (
        <div style={{ padding: '10px 16px 28px' }}>
          <button className="btn btn-primary" style={{ width: '100%' }} onClick={onDone}>OPEN PROTOCOL →</button>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Sheet, VerifySheet, ModifySheet, AskSheet, HistoryDrawer, SourcesDrawer, GeneratingScreen });
